////
// Call To Action Voice Chat Menu Preference File
////

	// Keybinds for accessing the Call To Action options via the quickchat menu (i.e. the V-menu)
	// I have chose what I feel at the best keybinds for a) accessing a menu that will be rarely used, but b) allow a user to
	// intuitively select that timer value they need. "ctaRootKey" is the submenu option that appears after you open the root 
	// menu (i.e. pressing V).
	//
	// By default, the number of available timers is kept simple for general use: 10, 20, and 30 seconds. However, if you feel
	// you want to add additional timers, then can easily be supported by defining the keybind.
	//
	// Feel free to change this to whatever you need / are comfortable with.
CTAVoiceChatMenu.callToActionMenuKeys["ctaRootKey"] = "Q"; // submenu key to open the call to action timer options
CTAVoiceChatMenu.callToActionMenuKeys["cta-10"] = "1"; // key for creating an action timer for 10 seconds
CTAVoiceChatMenu.callToActionMenuKeys["cta-20"] = "2"; // key for creating an action timer for 20 seconds
CTAVoiceChatMenu.callToActionMenuKeys["cta-30"] = "3"; // etc...

CTAVoiceChatMenu.callToActionMenuKeys["cta-40"] = "";
CTAVoiceChatMenu.callToActionMenuKeys["cta-50"] = "";
CTAVoiceChatMenu.callToActionMenuKeys["cta-60"] = "";
CTAVoiceChatMenu.callToActionMenuKeys["cta-15"] = "";
CTAVoiceChatMenu.callToActionMenuKeys["cta-25"] = "";
CTAVoiceChatMenu.callToActionMenuKeys["cta-35"] = "";
CTAVoiceChatMenu.callToActionMenuKeys["cta-45"] = "";
CTAVoiceChatMenu.callToActionMenuKeys["cta-55"] = "";
CTAVoiceChatMenu.callToActionMenuKeys["ctaCancel"] = "Q";