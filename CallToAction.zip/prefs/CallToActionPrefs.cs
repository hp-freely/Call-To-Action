////
// Call To Action is configured in two locations:
//   1) The in-game Options tab allows you to configure the one item that you might want to change on the fly: Max Number of Lines Displayed in a HUD
//   2) This prefs file allows you to configure all other items associated with the script.
////

	// a Call To Action means that a timer will be intiiated, and it some action must happen at the end of that timer (when it reaches 0).
	// However, it may be helpful to keep the timer up for a period of time after a time of 0. The variable below equals the total number of
	// seconds that a timer will be displayed *after* a time of 0 is reached. The timer value will be displayed in negative seconds.
	// The max value for this variable is 10. There's no reason to support more than that.
CallToAction.secondsToDisplayLineAfterTimerEnds = 5;

	// the maximum length of characters that will be displayed for a given player name in a line. If the max length
	// is reached, then the rest of the characters will be cut, and an elipses ("...") will replace them. (ex: "reallyLongName...")
	// If too many characters are in a given name, then that name will overflow down into the next line, which is annoying.
	// valid values: 5 through 20
CallToAction.actionCallerPlayerNameMaxLength = 13;

	// maximum number of "wide" characters permitted in a player name. This impacts how a given player name is truncted in order
	// to fit within the parent HUD
CallToAction.actionCallerPlayerNameMaxWideCharacters = 7;
		
	// the text value for the heading that appears at the top of the HUD
	// Setting this value to empty ("") will remove this text line from the HUD entirely.
CallToAction.hudConfigArr["HUD_Line_CTA_Text"] = "Call To Action:";

	// A max of 3 lines can be displayed. In concert with that, each line that gets displayed
	// will be assigned one of these colors. The colors will be dynamically recycled in the array index order
	// provided below. (see code for more details on how this is managed)
CallToAction.hudlineColorArr[0] = "11dd11"; // neon green
CallToAction.hudlineColorArr[1] = "ff3f20"; // ff3f20 medium red;
CallToAction.hudlineColorArr[2] = "33bbdd"; // light blue


// ------ Look and Feel Profiles ------------ //
/////
// There are a limited set of fonts supported by T2. These are located in the /fonts folder. Unfortunately,
// there are few fonts available to choose from, and I'm not sure you can generate fonts in the correct 
// format anymore. "Arial" and "Arial Bold" have the most options to play with.
//
// Given the above, from experimentation, I have found that there are two configurations that work best. 
// Profile 1: By default, I chose a profile that has larger text. This makes the CTA timer stand out more, so that you can quickly glance at it.
// I recommend showing the background, so that there is some contrast.
//
// Profile 2: If you want a smaller footprint, then Profile 2 uses a smaller font. The font is still bigger than what's used for other HUDs, because
// it's important to be able to quickly see the timer value. I recommend showing the background, so that there is some contrast.
//
// There is no dynamic way to apply a profile. However, I've basically set the settings for you below. Just uncomment the profile you want, and comment the 
// profile you don't want.
////

////   
// PROFILE 1: Larger Font
// Recommended HUD Transparency: 0.2. This is set in the options UI in the in-game browser.
////

	// width of parent HUD GUI
	// (the height of the HUD is dynamically calculated)
CallToAction.hudConfigArr["HUD_X_Width"] = 250;

	// control variables for the "Call To Action" heading that appears at the top of the HUD.
CallToAction.hudConfigArr["HUD_Line_CTA_Text_Y_Position"] = 3;
CallToAction.hudConfigArr["HUD_Line_CTA_Text_X_Position"] = 8;
CallToAction.hudConfigArr["HUD_Line_CTA_Text_Width"] = 200;
CallToAction.hudConfigArr["HUD_Line_CTA_Text_Height"] = 23;
CallToAction.hudConfigArr["HUD_Line_CTA_Text_Font_Color"] = "bfbbbb"; // offwhite
CallToAction.hudConfigArr["HUD_Line_CTA_Text_Font_Name"] = "Arial";
CallToAction.hudConfigArr["HUD_Line_CTA_Text_Font_Size"] = 21;

	// within the relative position of the GUI container, the lines assocaited with the CTA
	// timers should start at the Y position for this variable.
CallToAction.hudConfigArr["HUD_Line_Starting_Y_Position"] = 3;

	// height of each line in a HUD
CallToAction.hudConfigArr["HUD_Line_Height"] = 23;

	// positioning, width, height of the CTA text
CallToAction.hudConfigArr["HUD_Line_CTA_Timer_X_Position"] = 8;
CallToAction.hudConfigArr["HUD_Line_CTA_Timer_Width"] = 40;
CallToAction.hudConfigArr["HUD_Line_CTA_Timer_Height"] = 20;

	// positioning, width, height of the Player Name text
CallToAction.hudConfigArr["HUD_Line_Player_Name_X_Position"] = 60;
CallToAction.hudConfigArr["HUD_Line_Player_Name_Width"] = 190; // = right edge of parent HUD width
CallToAction.hudConfigArr["HUD_Line_Player_Name_Height"] = 20;

	// font family and size of the types of text in a given line
CallToAction.hudConfigArr["HUD_Line_Player_Name_Font_Name"] = "Arial";
CallToAction.hudConfigArr["HUD_Line_Player_Name_Font_Size"] = 21;

	// font family and size of the types of text in a given line
CallToAction.hudConfigArr["HUD_Line_CTA_Timer_Font_Name"] = "Arial";
CallToAction.hudConfigArr["HUD_Line_CTA_Timer_Font_Size"] = 21;

////   
// PROFILE 2: Smaller Font
////   Recommended HUD Transparency: 0.2. This is set in the options UI in the in-game browser.

	// width of parent HUD GUI
	// (the height of the HUD is dynamically calculated)
// CallToAction.hudConfigArr["HUD_X_Width"] = 220;

	// control variables for the "Call To Action" heading that appears at the top of the HUD.
// CallToAction.hudConfigArr["HUD_Line_CTA_Text_X_Position"] = 8;
// CallToAction.hudConfigArr["HUD_Line_CTA_Text_Y_Position"] = 5;
// CallToAction.hudConfigArr["HUD_Line_CTA_Text_Width"] = 130;
// CallToAction.hudConfigArr["HUD_Line_CTA_Text_Height"] = 23;
// CallToAction.hudConfigArr["HUD_Line_CTA_Text_Font_Color"] = "bfbbbb"; // offwhite
// CallToAction.hudConfigArr["HUD_Line_CTA_Text_Font_Name"] = "Arial Bold";
// CallToAction.hudConfigArr["HUD_Line_CTA_Text_Font_Size"] = 17;

	// within the relative position of the GUI container, the lines assocaited with the CTA
	// timers should start at the Y position for this variable.
// CallToAction.hudConfigArr["HUD_Line_Starting_Y_Position"] = 5;

	// height of each line in a HUD
// CallToAction.hudConfigArr["HUD_Line_Height"] = 23;

	// positioning, width, height of the CTA text
// CallToAction.hudConfigArr["HUD_Line_CTA_Timer_X_Position"] = 8;
// CallToAction.hudConfigArr["HUD_Line_CTA_Timer_Width"] = 35;
// CallToAction.hudConfigArr["HUD_Line_CTA_Timer_Height"] = 20;

	// positioning, width, height of the Player Name text
// CallToAction.hudConfigArr["HUD_Line_Player_Name_X_Position"] = 50;
// CallToAction.hudConfigArr["HUD_Line_Player_Name_Width"] = 170; // = right edge of parent HUD width
// CallToAction.hudConfigArr["HUD_Line_Player_Name_Height"] = 20;

	// font family and size of the types of text in a given line
// CallToAction.hudConfigArr["HUD_Line_Player_Name_Font_Name"] = "Arial Bold";
// CallToAction.hudConfigArr["HUD_Line_Player_Name_Font_Size"] = 17;

	// font family and size of the types of text in a given line
// CallToAction.hudConfigArr["HUD_Line_CTA_Timer_Font_Name"] = "Arial Bold";
// CallToAction.hudConfigArr["HUD_Line_CTA_Timer_Font_Size"] = 17;